# speccheck: management paper and presentation

Start with **[paper.pdf](paper.pdf)**: 34 pages, including a 15-page main text, front matter, references and technical appendices. The companion **[slides.pdf](slides.pdf)** has 29 main slides and 11 appendix slides. It presents the same argument through running examples: order processing, deletion versus retention, and authentication. Both describe source revision `498dea06df250964013b2abb2b06c94d341b223b`; this documentation edition is dated 25 November 2026.

The language is deliberately colleague-to-colleague. Essential definitions, short listings and examples stay in the main argument. Detailed pseudocode and replay instructions are in the technical appendices. Constructed examples are distinguished from saved experiment output.

## What changed in this edition

The documents now cover removal-aware change checking and optional reuse of a saved base model. The order example shows how deleting a response can open a gap attributed to the removed rule. A second workflow diagram explains what reuse preserves and what still gets checked.

E19 and E20 extend the evaluation. The cost comparison includes the initial base-building cost and the measured loss in conflict detection. Full formalization remains the default. Incremental mode currently extracts scenario edits; a requirement-sentence-only edit can reuse the old model without translating the new sentence. This limitation is explicit in the method and discussion.

See **[EDITION-2026-11-25.md](EDITION-2026-11-25.md)** for the changes, evidence boundaries and preserved revisions.

## What is included

- `paper.tex` and `sections/`: the paper, algorithms and bibliography.
- `slides.tex`: the Beamer deck, including presenter notes in the source.
- `shared/`: common notation, colors, and editable diagrams.
- `evidence/`: evaluation metrics, claims-to-source index, review records and checked examples.
- `snapshot/2026-11-24-498dea0/`: complete tracked source and recorded evidence for this edition, with checksums.
- `snapshot/2026-11-24-18752f2/`: the previous source snapshot, preserved unchanged.
- `UPDATE.md`: how to update this edition when the project changes.
- `scripts/`: build, snapshot verification, comparison, packaging and example checks.

Snapshot directory dates are the source commits' dates. The current commit is dated 24 November; the documentation was revised on 25 November. No application code or historical result file was changed to create this edition. The previous full delivery, `speccheck-management-2026-11-24.zip`, remains alongside the new edition in the working folder and is excluded from the new delivery ZIP.

## Structure and presentation route

The presentation follows an academic argument: motivation and research question, approach, essential mechanisms, worked use, evaluation, limitations and conclusions. Detailed algorithms are in the appendix, with links from the main slides and back.

| Main slides | Part |
| --- | --- |
| 1-4 | Motivation, research question and contribution |
| 5-7 | Architecture and basic model |
| 8-13 | Main mechanisms and running examples |
| 14-18 | Reviewing a finding, checking a change, removal and reuse |
| 19-25 | Evaluation setup, measures and RQ1-RQ4 results |
| 26-27 | Representation failures and limits of the evidence |
| 28-29 | Next work and conclusions |

Appendices A-K are for questions and are outside the planned 31 minutes 15 seconds for the main talk. The main slides retain short listings and diagrams; all eleven detailed algorithms are available in the paper's technical appendices. Timing in the presenter notes is a pacing plan, not a measured rehearsal.

The evaluation distinguishes conflict detection and extra alarms, ambiguity and extra questions, changes in context, and scale/cost. Historical E17 and E18 results keep their original identities. E19 tested design `07ecd38`; E20 tested `373ae4c`. The current cache and command-line restrictions in `498dea0` were added after E20 and were not measured by it.

Source pointers remain in the editable LaTeX and evidence index. Internal file references, package instructions and review notes do not appear as paper or slide footers.

## Build the PDFs

Use a TeX installation with pdfLaTeX, BibTeX, Beamer, TikZ/PGFPlots, newtx, algorithm/algorithmicx, natbib, cleveref and the standard packages in the preambles. The build uses direct passes; Perl and latexmk are not required.

From the repository root in PowerShell:

```powershell
& .\docs\management\scripts\build.ps1
```

From a standalone delivered folder, run `scripts/build.ps1` there. It resolves paths from its own location. Use `-Target paper` or `-Target slides` to build just one. Add `-Render` to create page images using `pdftoppm`; rendering tools are not needed merely to compile the PDFs. Logs and previews go under `build/`.

If an earlier PDF is open and Windows prevents replacement, use `-PdfSuffix '-updated'` to write separate PDFs. To package those under the standard names, run `scripts/package.ps1 -PaperPdf <paper path> -SlidesPdf <slides path>`. Earlier PDF variants remain in the working folder and are excluded from the delivery ZIP.

The default package name is `speccheck-management-2026-11-25.zip`. Its adjacent `.sha256` file records the checksum. Both source snapshots are included; the previous full delivery ZIP is not nested inside it.

The diagrams and charts are native LaTeX/TikZ/PGFPlots sources. The paper and slides have no network dependency at build time.

## Recheck the examples

Extract the current snapshot into `build/baseline-498dea0`. In the original repository:

```powershell
& .\docs\management\scripts\snapshot.ps1 `
  -ExtractTo .\docs\management\build\baseline-498dea0
```

In a standalone package, unzip `snapshot/2026-11-24-498dea0/source.zip` into that directory and use the comparison script described in `UPDATE.md`.

With the project dependencies from the archived `uv.lock` available, run the example script using that project's interpreter. For the current Windows workspace:

```powershell
& .\.venv\Scripts\python.exe .\docs\management\scripts\verify-examples.py
```

The script imports the extracted source and checks 31 examples and boundary cases, including removal attribution, event retirement, the saved visitor finding and unsupported sentence-only incremental edits. It records the outcome in `evidence/example-checks.json` and makes no LLM calls. The current archived project also has 70 offline tests; see `evidence/validation.json` for the recorded run.

The original model experiments remain historical evidence. This package does not include model weights or GPU services and does not claim that resampling will recreate identical model answers.

## Updating later

Keep the whole package, especially the snapshot and evidence index. Follow **[UPDATE.md](UPDATE.md)** and compare the next source version with the archived revision first. The update can then identify which explanations, diagrams, examples and evaluation claims need to change without relying on chat history.
