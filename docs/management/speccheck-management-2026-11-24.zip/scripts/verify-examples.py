"""Check the actual examples used in the documents against the frozen implementation.

Run with the project's Python environment, after extracting snapshot/source.zip
to build/baseline. No model server is called and no archived file is changed.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--baseline', type=Path, default=ROOT / 'build' / 'baseline')
args = parser.parse_args()
baseline = args.baseline.resolve()
if not (baseline / 'speccheck' / 'formalize.py').is_file():
    raise SystemExit('Extract the source snapshot into build/baseline first.')
sys.path.insert(0, str(baseline))

from speccheck.logic import Vocabulary
from speccheck.formalize import _judge, judge_second
from speccheck.checks import analyze

checks = []

def record(name, condition, detail):
    if not condition:
        raise AssertionError(name + ': ' + detail)
    checks.append({'name': name, 'passed': True, 'detail': detail})

def sym(name, sort='Bool', event=False):
    return {'name': name, 'sort': sort, 'values': [], 'description': name, 'event': event}

vocab = Vocabulary([sym(x, event=x in ('s', 'c')) for x in ('s','v','f','b','c','q','u')])
defs = [('R1','(and s v)','f'), ('R2','(and s (not v))','b'),
        ('R3','true','(not b)'), ('R4','c','u'), ('R5','q','(not f)')]
rules = [vocab.rule({'id': i, 'antecedent': a, 'consequent': c}) for i,a,c in defs]
phi = [r.formula for r in rules]
trigger = vocab.parse('(and s (not v))')
record('Order global satisfiability', vocab.model(phi) is not None,
       'All implications can hold when nothing triggers; global SAT alone misses R2/R3.')
record('Order feasible trigger', vocab.model([trigger]) is not None, 'Submitted, no stock is feasible.')
record('Order R2/R3 contradiction', vocab.impossible([trigger, rules[1].formula, rules[2].formula]),
       'The feasible trigger forces b and not b.')
record('Order R1/R5 contradiction', vocab.impossible([vocab.parse('(and s v q)'), rules[0].formula, rules[4].formula]),
       'Submission, stock and canceled/refunded force f and not f.')
assumption=vocab.parse('(not (and f q))')
other_trigger=vocab.parse('(and s v q)')
record('Assumption does not exclude the trigger', vocab.model([other_trigger,assumption]) is not None,
       'The assumed exclusion of fulfillment and refunded state leaves the triggering context feasible.')
record('Assumption can make R1 alone impossible', vocab.impossible([other_trigger,assumption,rules[0].formula]),
       'A facts-only pass can reject the case through single-rule exclusion; rules-only checking preserves R1/R5.')
record('Order allowed scenario', vocab.model(phi+[vocab.parse('(and (not s) (not c) (not q) (not b) f)')]) is not None,
       'Fulfillment without submission is permitted by the encoded requirements.')
record('Order quiet uncovered state', vocab.model([vocab.parse('(and (not s) (not c) (not q))')]+
       [vocab.parse('(not '+a+')') for i,a,c in defs if i != 'R3']) is not None,
       'No conditional antecedent applies; R3 is an unconditional prohibition.')

# A generalized gap describes a region, not one fully specified valuation.
# The baseline sensitivity mark only needs the alternative to cover some of it.
sensitivity = {
    'symbols': [sym(name, event=name == 's') for name in ('s', 'x', 'y', 'f')],
    'rules': [{
        'id': 'R1', 'trigger': 's', 'status': 'ambiguous',
        'text': 'Illustrative rule with two possible conditions',
        'reading': 'Respond to s when x holds',
        'antecedent': '(and s x)', 'consequent': 'f',
        'alternative': {'reading': 'Respond to s when y holds',
                        'antecedent': '(and s y)', 'consequent': 'f'},
    }],
}
sensitivity_findings = analyze(sensitivity)
event_gap = next(finding for finding in sensitivity_findings
                 if finding['type'] == 'gap' and finding.get('event') == 's')
ambiguity = next(finding for finding in sensitivity_findings if finding['type'] == 'ambiguity')
record('Generalized event gap', event_gap['when'] == {'s': True, 'x': False},
       'The original s-and-x rule leaves s true and x false uncovered; y is unspecified.')
record('Partial-coverage sensitivity annotation',
       'R1' in event_gap.get('depends_on_reading', {})
       and ambiguity['other_reading']['covers_gaps'] == 1,
       'The alternative s-and-y rule marks the original generalized gap as reading-dependent.')
variant = {**sensitivity, 'rules': [{**sensitivity['rules'][0],
                                   'status': 'accepted', 'antecedent': '(and s y)'}]}
sensitivity_vocab = Vocabulary(sensitivity['symbols'])
uncovered_completion = sensitivity_vocab.parse('(and s (not x) (not y))')
no_alternative_response = sensitivity_vocab.parse('(not (and s y))')
record('Alternative leaves uncovered completion',
       sensitivity_vocab.model([uncovered_completion, no_alternative_response]) is not None
       and any(finding['type'] == 'gap' and finding.get('event') == 's'
               for finding in analyze(variant)),
       's true, x false, y false remains uncovered after substitution; the mark is not full coverage.')

auth = Vocabulary([sym('n','Int'),sym('locked')])
def translation(a, c='locked'):
    return {'reading': 'Illustrative threshold reading', 'antecedent': a, 'consequent': c}
a=translation('(= n 5)')
b=translation('(>= n 5)')
d=translation('(> n 5)')
ar=auth.rule({'id':'A',**a}); br=auth.rule({'id':'B',**b})
witness=auth.parse('(and (= n 6) (not locked))')
record('Authentication distinct readings', not auth.same_meaning(ar,br), 'Exactly five and at least five differ.')
record('Authentication explicit witness', auth.model([witness,ar.formula]) is not None and auth.impossible([witness,br.formula]),
       'n=6, unlocked obeys the exact-five implication and violates at-least-five.')
for sizes, expected in [([8], 'accepted'),([7,1],'accepted'),([6,2],'ambiguous'),([5,3],'ambiguous'),([4,2,2],'rejected')]:
    answers=[t for t,count in zip([a,b,d],sizes) for _ in range(count)]
    result=_judge(auth,answers)
    record('Cluster '+str(sizes), result['status']==expected,
           f"Entropy {result['entropy']}; initial status {expected}; constructed samples, not a model experiment.")
second=judge_second(auth,{'id':'A',**a},[a]*3+[b]*5,8)
record('Second-reader illustration', second['support']=='3/8' and not second['confirms'] and 'antecedent' in second,
       'Three matching answers out of eight do not confirm; a usable alternative exists.')

delete=Vocabulary([sym('d'),sym('m'),sym('k')])
obligations=[delete.parse('(=> d m)'),delete.parse('k'),delete.parse('d')]
record('Deletion without assumed link', delete.model(obligations) is not None,
       'Separate removal and retention symbols can both hold.')
record('Deletion with assumed link', delete.impossible(obligations+[delete.parse('(=> (and d m) (not k))')]),
       'The explicit illustrative link exposes the D2/D4 clash; it remains an assumption.')

saved=json.loads((baseline/'specs/order/formal.json').read_text(encoding='utf-8'))
findings=analyze(saved)
conflicts={frozenset(x['rules']) for x in findings if x['type']=='conflict'}
record('Saved order model replay', {frozenset(['R2','R3']),frozenset(['R1','R5'])} <= conflicts,
       'Frozen specs/order/formal.json yields both named order conflicts under the archived implementation.')
record('Saved quiet gap', any(x['type']=='gap' and x.get('quiet') for x in findings),
       'The archived order model yields a quiet gap.')
without_backorder = {**saved, 'rules': [rule for rule in saved['rules'] if rule['id'] != 'R2']}
record('Missing no-stock response creates event gap',
       any(finding['type'] == 'gap' and finding.get('event') == 'order_submitted'
           and finding['when'].get('order_submitted') is True
           and finding['when'].get('inventory_available') is False
           for finding in analyze(without_backorder)),
       'Removing R2 leaves R1 reacting to submission and exposes a submitted, no-stock coverage gap.')

manifest=json.loads((ROOT/'snapshot/2026-11-24-18752f2/manifest.json').read_text(encoding='utf-8-sig'))
report={'snapshot_revision':manifest['commit'], 'baseline':str(baseline),
        'python':sys.version.split()[0], 'z3_solver':importlib.metadata.version('z3-solver'),
        'network_calls':0, 'checks':checks, 'passed':len(checks)}
out=ROOT/'evidence/example-checks.json'
out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(f'{len(checks)} example checks passed; {out}')
