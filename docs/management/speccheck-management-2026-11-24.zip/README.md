# speccheck: management paper and presentation

Start with **[paper.pdf](paper.pdf)**: 29 pages, with a 12-page main text followed by references and technical appendices, plus the title/abstract and contents pages. The companion **[slides.pdf](slides.pdf)** has 26 main slides and 14 technical appendix slides. Both explain the same fixed project revision through running examples: order processing, deletion versus retention, and authentication.

The prose is deliberately colleague-to-colleague. The formal definitions, pseudocode, diagrams and evidence are there to make the explanation precise. Simplified formulas and constructed sample splits are marked as illustrations.

## What is included

- `paper.tex` and `sections/`: the paper, algorithms and bibliography.
- `slides.tex`: the Beamer deck, including presenter notes in the source.
- `shared/`: common notation, colors, and editable diagrams.
- `evidence/`: evaluation metrics, claims-to-source index, and checked examples.
- `snapshot/2026-11-24-18752f2/`: complete tracked source and recorded evidence for the approved revision, with checksums.
- `UPDATE.md`: how to update this edition when the project changes.
- `scripts/`: build, snapshot verification, future-version comparison, and example checks.

The baseline is `18752f24cbfd625d23d7ae5bd967af43ee7af718`, dated 24 November 2026. Work added later to the live project, including `eval13`, is outside this edition. No application code or historical result file was changed to create these documents.

## Structure and presentation route

The main presentation follows an academic argument: motivation and research question, approach, essential mechanisms, worked use, evaluation, limitations and conclusions. Detailed algorithms, solver traces and replay instructions are in the appendix. Links within the slides jump to the relevant details and back.

The speaker notes budget **26 minutes 45 seconds** for the 26 main slides. Appendix slides A–N are for questions and are outside that timing. This is a pacing plan, not a measured rehearsal.

| Slides | Part |
| --- | --- |
| 1–4 | Motivation, research question and contribution |
| 5–7 | Architecture and basic model |
| 8–13 | Main mechanisms and running examples |
| 14–16 | Reviewing a finding and checking a change |
| 17–22 | Evaluation setup, measures and RQ1–RQ4 results |
| 23–24 | Representation failures and limits of the evidence |
| 25–26 | Next work and conclusions |

The evaluation answers four questions in the same order in both documents: conflict detection and extra alarms; ambiguity and extra questions; changes in context; and scale. The main slides retain short listings and diagrams, with saved excerpts and constructed illustrations labelled separately.

Six main slides contain listings: requirements (2), translation (8), a distinguishing witness (9), an allowed snapshot (13), a saved finding (14), and an added scenario (16). Nine main slides use explanatory diagrams, and slide 19 has two charts. Full pseudocode is in the appendices.

The paper introduces the problem and formal model before the method. Experimental setup, results and discussion are separate sections. All ten detailed algorithms are collected in an appendix, with references from their explanations in the main text.

The full review corrected an omitted UNSAT gate in pseudocode, an overstated gap-sensitivity claim, roadmap ordering, undefined notation and evaluation labels. The appendix includes a saved input-to-output walkthrough. See `evidence/review.json` for the review record.

The final wording pass removed internal file references from the printed pages and simplified the prose. Source pointers remain in the editable LaTeX and evidence index. Package and update instructions stay here rather than appearing in the paper or presentation.

The review also inspected live revision `07aef5d`, which contains later removal-aware change checking and E19 results. These advances are outside this historical baseline; use `UPDATE.md` before presenting this as a report on the latest code.

## Build the PDFs

Use a TeX installation with pdfLaTeX, BibTeX, Beamer, TikZ/PGFPlots, newtx, algorithm/algorithmicx, natbib, cleveref and the standard packages used in the preambles. The build uses direct passes; Perl and latexmk are not required.

From the repository root in PowerShell:

```powershell
& .\docs\management\scripts\build.ps1
```

From a standalone delivered folder, run `scripts/build.ps1` there. It resolves paths from its own location. Use `-Target paper` or `-Target slides` to build just one. Add `-Render` to create page images using `pdftoppm`; rendering tools are not needed merely to compile the PDFs. Logs and previews go under `build/`.

If an earlier PDF is open and Windows prevents replacement, use `-PdfSuffix '-academic'` to write `paper-academic.pdf` and `slides-academic.pdf`. To package these under the standard names, run `scripts/package.ps1 -PaperPdf <paper path> -SlidesPdf <slides path>`. Earlier PDF variants remain in the working folder and are excluded from the delivery ZIP.

The diagrams and charts are native LaTeX/TikZ/PGFPlots sources. The paper and slides have no network dependency at build time.

## Recheck the examples

Extract the snapshot into `build/baseline`. In the original repository, `scripts/snapshot.ps1 -ExtractTo <path>` does that while verifying the archive. In a standalone package, unzip `snapshot/2026-11-24-18752f2/source.zip` into that directory and use the comparison script described in `UPDATE.md`.

With the project dependencies from the archived `uv.lock` available, run the example script using that project's interpreter. For the current Windows workspace:

```powershell
& .\.venv\Scripts\python.exe .\docs\management\scripts\verify-examples.py
```

The script imports the extracted baseline, checks the running formulas and the saved order model, and records the result in `evidence/example-checks.json`. It makes no LLM calls. The baseline's existing test suite can also be run from the extracted directory with that interpreter: `python -m pytest -q`.

The original model runs remain historical evidence. This package does not include model weights or GPU services and does not claim that resampling will recreate identical model answers.

## Updating later

Keep the whole package, especially the snapshot and evidence index. When the project is ready for another edition, follow **[UPDATE.md](UPDATE.md)** and compare the new files with the archived baseline first. The update can then identify which explanations, diagrams, examples and evaluation claims need to change without relying on chat history.
