# Updating the paper and slides

The documents describe one fixed project version. You do not need this chat to update them later: the source archive, manifest, saved experiments and evidence index are the record.

## What this edition preserves

The baseline is commit `18752f24cbfd625d23d7ae5bd967af43ee7af718`, dated 24 November 2026. Its files are in `snapshot/2026-11-24-18752f2/source.zip`. The adjacent `manifest.json` records the Git tree, archive checksum, each original file's checksum, dependency lock versions and the model configuration found in the deployment scripts. `SHA256SUMS.txt` also covers the manifest itself.

The archive contains all tracked files from that revision, including raw experiment JSON, the inputs and expected defects, saved formal models, result overlays and their original result files. It does not contain a virtual environment, model weights, GPU services, local secrets or Git history. It is enough to inspect the exact evidence and replay solver checks once the dependencies are installed. It is not a promise that a new model run will produce the same samples.

The snapshot revision is the version being explained. Most older experiments do not record the exact source commit that produced them. Keep that distinction when citing historical results. Archive creation disables automatic checkout line-ending conversion and checks every archived file against its Git blob identifier. The manifest also includes normalized text hashes so future Windows checkouts can distinguish line-ending changes from content changes.

## Inspect or verify the baseline

From the repository root, with PowerShell:

```powershell
& .\docs\management\scripts\snapshot.ps1
```

This verifies the existing archive and every archived file against the manifest. It never replaces an existing snapshot with different content. In the original Git repository, you can also extract a checked working copy:

```powershell
& .\docs\management\scripts\snapshot.ps1 `
  -ExtractTo .\docs\management\build\baseline
```

The script resolves the chosen revision through Git, so it needs the original Git history. If all you have is the delivered folder, unzip `source.zip` into a fresh directory and compare it with the manifest instead:

```powershell
& .\docs\management\scripts\compare-snapshot.ps1 `
  -NewProjectDirectory C:\Work\speccheck-baseline
```

Expect no added, changed or removed files. `Get-FileHash -Algorithm SHA256` can independently check the archive against `SHA256SUMS.txt`. A damaged or incomplete snapshot should be preserved for inspection rather than overwritten.

## Compare the next project version

Point the comparison script at the new version. It can be a Git checkout or an ordinary directory:

```powershell
& .\docs\management\scripts\compare-snapshot.ps1 `
  -NewProjectDirectory C:\Work\speccheck-next
```

Read `build/snapshot-diff.json`. It lists added, changed and removed paths, their hashes, and the document topics they are likely to affect. Windows checkout line endings are reported separately from substantive changes. The comparison skips this documentation package, caches, virtual environments and build outputs; it does not modify the new project. It skips directory links rather than traversing outside the project.

Use the evidence index beside the paper sources to find the specific claims, formulas, figures and examples affected by each change. In particular:

- Changes to `formalize.py`, `probe.py` or `logic.py` usually require another look at the seven steps, their pseudocode and the meaning of their guarantees.
- Changes to `checks.py` can change conflict, gap and scenario semantics. Replay the running examples and inspect the witnesses.
- Changes to `change.py` can change which OpenSpec findings are attributed to a change.
- New benchmark inputs or raw results may change the evaluation, but keep experiment identities, configuration and scoring units intact.
- New deployment scripts or dependency locks may change runtime, capacity and reproduction instructions.

## Revise the explanation and its evidence together

1. Preserve the previous paper, slides and snapshot as an edition before starting the update.
2. Choose the exact new revision. With Git, run `snapshot.ps1 -Revision <full-commit>`; it creates a separate dated directory. If the new version has no Git history, preserve its supplied files and record that provenance explicitly rather than inventing a commit.
3. Inspect the code and original evidence for each affected claim. Old overview prose is a guide, not the final source of truth.
4. Update the paper first. Keep the running examples' requirement IDs and notation stable where possible. If an example no longer demonstrates the mechanism, explain why before replacing it. Keep essential definitions and examples in the main text, with detailed algorithms in the appendices.
5. Update the evidence index and `evidence/metrics.json`, then the shared figures and slides. Keep the paper and presentation aligned around the same research questions, and update claim-to-slide references and appendix links after reordering. Label new illustrative samples as illustrations; do not mix them with measured output.
6. Recheck formulas and saved-model examples, rerun the offline suite, build both PDFs, and inspect every rendered page and slide.
7. Add a brief edition note: changes in behaviour, changes in evidence, unchanged limitations, and anything still unmeasured.

For evaluation, distinguish counts of findings, counts of flagged rules and counts of runs. Retain filtered and unfiltered results where the distinction matters. A historical test set that has informed a design change is development data for the next design. Do not pool incompatible configurations into a single project accuracy figure.

The final handoff should include the revised PDFs, editable sources, new snapshot, updated evidence index and the edition note. That is what the next update can start from.
