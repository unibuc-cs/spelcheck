# speccheck: management paper and presentation

Start with **[paper.pdf](paper.pdf)**: 34 pages, comprising 2 pages of front matter, 15 pages of main text, 1 page of references and 16 pages of technical appendices. The companion **[slides.pdf](slides.pdf)** has 29 main slides and 11 appendix slides. Order processing is the main teaching example; an authentication project shows how OpenSpec changes are checked. Deletion versus retention is a brief supporting example for assumptions. Both documents describe source revision `498dea06df250964013b2abb2b06c94d341b223b`; this documentation edition is dated 25 November 2026.

The language is deliberately colleague-to-colleague. Essential definitions, short listings and examples stay in the main argument. Detailed pseudocode and replay instructions are in the technical appendices. Constructed examples are distinguished from saved experiment output.

## What changed in this edition

The paper and presentation now follow six sections: Problem and example, Method, Findings, Changes, Evaluation, and Limitations and next steps. Slide titles name the topic within each section. The order example is introduced as a complete case before its rules are used in later explanations, and links lead to the exact example sources. This is an editorial regrouping; it does not advance the application baseline or add experimental results.

The documents now cover removal-aware change checking and optional reuse of a saved base model. The order example shows how deleting a response can open a gap attributed to the removed rule. A second workflow diagram explains what reuse preserves and what still gets checked.

E19 and E20 extend the evaluation. The cost comparison includes the initial base-building cost and the measured loss in conflict detection. Full formalization remains the default. Incremental mode currently extracts scenario edits; a requirement-sentence-only edit can reuse the old model without translating the new sentence. This limitation is explicit in the method and discussion.

See **[EDITION-2026-11-25.md](EDITION-2026-11-25.md)** for the changes, evidence boundaries and preserved revisions.

## What is included

- `paper.tex` and `sections/`: the paper, algorithms and bibliography.
- `slides.tex`: the Beamer deck, including presenter notes in the source.
- `shared/`: common notation, colors, and editable diagrams.
- `evidence/`: evaluation metrics, claims-to-source index, review records and checked examples.
- `snapshot/2026-11-24-498dea0/`: complete tracked source and recorded evidence for this edition, with checksums.
- `snapshot/2026-11-24-18752f2/`: the previous source snapshot, preserved unchanged.
- `UPDATE.md`: how to update this edition when the project changes.
- `scripts/`: build, snapshot verification, comparison, packaging and example checks.

Snapshot directory dates are the source commits' dates. The archived application commit is dated 24 November; the documentation was revised on 25 November. Live revision `cb0a5c0053ae29544f10f2a7646fc0fee94d1884` was also inspected: its changes after the baseline affect only `GUIDE.md` and the repository `README.md`. No application code or historical result file was changed to create this edition. The previous full delivery, `speccheck-management-2026-11-24.zip`, and the earlier 25 November delivery, `speccheck-management-2026-11-25-before-grouping.zip`, remain in the working folder and are excluded from the new delivery ZIP.

## Structure and presentation route

The paper and presentation follow the same six-part academic argument. The cover is slide 1. Detailed algorithms are in the appendix, with links from the main slides and back.

| Main slides | Part |
| --- | --- |
| 2-4 | 1. Problem and example |
| 5-10 | 2. Method |
| 11-14 | 3. Findings |
| 15-18 | 4. Changes |
| 19-25 | 5. Evaluation |
| 26-29 | 6. Limitations and next steps |

Appendices A-K are for questions and are outside the planned 31 minutes 15 seconds for the main talk. The main slides retain short listings and diagrams; all eleven detailed algorithms are available in the paper's technical appendices. Timing in the presenter notes is a pacing plan, not a measured rehearsal.

After regrouping, all 40 rendered slides and all 34 rendered paper pages were visually reviewed. The main-slide timings were checked and total 1,875 seconds, matching the pacing plan above.

The evaluation distinguishes conflict detection and extra alarms, ambiguity and extra questions, changes in context, and scale/cost. Historical E17 and E18 results keep their original identities. E19 tested design `07ecd38`; E20 tested `373ae4c`. The current cache and command-line restrictions in `498dea0` were added after E20 and were not measured by it.

Source pointers remain in the editable LaTeX and evidence index. Internal file references, package instructions and review notes do not appear as paper or slide footers.

## Read the examples

The links below are pinned to the documented source revision, so future repository changes do not alter the examples discussed here.

- **[Order requirements (EARS)](https://github.com/unibuc-cs/spelcheck/blob/498dea06df250964013b2abb2b06c94d341b223b/specs/order/requirements.md):** the five-rule teaching case used for text, formulas, conflicts and allowed scenarios. Removing its no-stock response is an explicitly constructed variation. This file is not an OpenSpec specification.
- **[Authentication base specification (OpenSpec)](https://github.com/unibuc-cs/spelcheck/blob/498dea06df250964013b2abb2b06c94d341b223b/specs/auth_change/openspec/specs/auth/spec.md):** the existing login and account-lockout scenarios, including the phrase "reaches 5" used to explain ambiguity.
- **[Administrator-access change (OpenSpec)](https://github.com/unibuc-cs/spelcheck/blob/498dea06df250964013b2abb2b06c94d341b223b/specs/auth_change/openspec/changes/admin-never-locked/specs/auth/spec.md):** the proposed requirement that administrators must not be locked out. It shows why a change must be checked with the existing specification.

These small cases let the audience follow each reasoning step and check it by hand. They explain the method; the separate evaluation section reports measured results and their limits. The examples do not establish performance on independent production requirements.

## Build the PDFs

Use a TeX installation with pdfLaTeX, BibTeX, Beamer, TikZ/PGFPlots, newtx, algorithm/algorithmicx, natbib, cleveref and the standard packages in the preambles. The build uses direct passes; Perl and latexmk are not required.

From the repository root in PowerShell:

```powershell
& .\docs\management\scripts\build.ps1
```

From a standalone delivered folder, run `scripts/build.ps1` there. It resolves paths from its own location. Use `-Target paper` or `-Target slides` to build just one. Add `-Render` to create page images using `pdftoppm`; rendering tools are not needed merely to compile the PDFs. Logs and previews go under `build/`.

If an earlier PDF is open and Windows prevents replacement, use `-PdfSuffix '-updated'` to write separate PDFs. To package those under the standard names, run `scripts/package.ps1 -PaperPdf <paper path> -SlidesPdf <slides path>`. Earlier PDF variants remain in the working folder and are excluded from the delivery ZIP.

The default package name is `speccheck-management-2026-11-25.zip`. Its adjacent `.sha256` file records the checksum. Both source snapshots are included; the previous delivery ZIPs are not nested inside it. The preserved `speccheck-management-2026-11-25-before-grouping.zip` has SHA-256 `f99995d025295e5ff7255c69677663a6ec0157836893c2e36e926cdfe985dd0a`.

The diagrams and charts are native LaTeX/TikZ/PGFPlots sources. The paper and slides have no network dependency at build time.

## Recheck the examples

Extract the current snapshot into `build/baseline-498dea0`. In the original repository:

```powershell
& .\docs\management\scripts\snapshot.ps1 `
  -ExtractTo .\docs\management\build\baseline-498dea0
```

In a standalone package, unzip `snapshot/2026-11-24-498dea0/source.zip` into that directory and use the comparison script described in `UPDATE.md`.

With the project dependencies from the archived `uv.lock` available, run the example script using that project's interpreter. For the current Windows workspace:

```powershell
& .\.venv\Scripts\python.exe .\docs\management\scripts\verify-examples.py
```

The script imports the extracted source and checks 31 examples and boundary cases, including removal attribution, event retirement, the saved visitor finding and unsupported sentence-only incremental edits. It records the outcome in `evidence/example-checks.json` and makes no LLM calls. The current archived project also has 70 offline tests; see `evidence/validation.json` for the recorded run.

The original model experiments remain historical evidence. This package does not include model weights or GPU services and does not claim that resampling will recreate identical model answers.

## Updating later

Keep the whole package, especially the snapshot and evidence index. Follow **[UPDATE.md](UPDATE.md)** and compare the next source version with the archived revision first. The update can then identify which explanations, diagrams, examples and evaluation claims need to change without relying on chat history.
